/*  EXERCICI 1
	Una empresa d'autobusos ofereix descomptes de grup en el preu del bitllet, en
	funci� de la quantitat de persones del grup. El programa haur� de demanar el preu
	del bitllet i el nombre de persones i haur� de mostrar el preu de cada bitllet (amb
	el descompte aplicat si escau) i el total de l'import del grup. Els descomptes a aplicar
	s�n:
		a. Per m�s de 50 persones: 30% de descompte.
		b. Entre 25 i 50 persones (ambdues inclusivament): 25% de descompte.
		c. Entre 10 i 24 persones (ambdues inclusivament): 15% de descompte.
		d. Menys de 10 menys persones ja no es considera un grup i per tant no s'aplica
		cap descompte.
*/

#include <stdio.h>

int main(void) {
	int persones;
	float preu, descompte=0, total;

	printf("Introdueix el preu del bitllet: ");
	scanf("%f", &preu);
	
	printf("Introdueix el numero de persones: ");
	scanf("%d", &persones);
	
	if(persones>50) {
		descompte = 30;
	} else if(persones>=25 && persones<=50) {
		descompte = 25;
	} else if(persones>=10 && persones<=24) {
		descompte = 15;
	}
	
	preu = preu*(1-descompte/100);
	total = persones*preu;
	
	printf("El preu de cada bitllet es: %.2f EUR\n", preu);
	printf("El total de l'import del grup es: %.2f EUR\n", total);
}
