/*  EXERCICI 2
	Escriu un programa que sumi una seq��ncia de n�meros enters i calcula la seva mitjana.
	El programa anir� demanant n�meros un per un fins entrar un -1 que far� que finalitzi el programa.
	Abans de finalitzar el programa, es mostrar� per pantalla la mitjana dels n�meros introdu�ts amb 2
	decimals.
	Utilitza l�estructura do-while per realitzar la peticions de n�meros.
*/

#include <stdio.h>

int main(void) {
	int valor, numeros;
	float suma, mitjana;
	
	do {
		printf("Introdueix un nombre: ");
		scanf("%d", &valor);
		
		if(valor!=-1) {
			suma+=valor;
			numeros++;
		}
		
	} while(valor!=-1);
	
	mitjana=suma/numeros;
	
	printf("La mitjana dels nombres introduits es: %.2f", mitjana);
}
