/*  EXERCICI 3
	Escriu un programa que converteixi temperatures entre 30� C i 50� C a l�escala Fahrenheit.
	Per convertir de Celsius a Fahrenheit utilitza la conversi� �F=9/5*�C+32
	El programa haur� d�imprimir una taula mostrant les temperatures de les 2 escales (les
	temperatures Fahrenheit amb 1 decimal).
	Utilitza l�estructura while per imprimir els valors de la taula.
*/

#include <stdio.h>

int main(void) {
	float celsius=30, fahrenheit;
	
	printf("Celsius\tFahrenheit\n");
	
	while(celsius<=50) {
		fahrenheit = 9/5.0*celsius+32;
		printf("%.1f C\t%.1f F\n", celsius, fahrenheit);
		celsius++;
	}
}
