/*  EXERCICI 4
	Escriu un programa que imprimeixi els seg�ents patrons per separat, un a sota de l�altre.
	Utilitza bucles for per generar els patrons.
*/

#include <stdio.h>

int main(void) {
	int i, j, k;

	// PATR� 1
 	for(i=1; i<=10; i++) {
		// Imprimim els asteriscs depenent de la l�nia
		for(j=1; j<=i; j++) {
 			printf("*");
		}
		
		// Canviem de l�nia
		printf("\n");
	}
	
	printf("\n");
	
	// PATR� 2
	for(i=10; i>=1; i--) {
		// Imprimir espais en blanc al davant depenent de la l�nia
		for(k=0; k<10-i; k++) {
			printf(" ");
		}

		// Imprimir els asteriscs depenent de la l�nia
		for(j=i; j>=1; j--) {
			printf("*");
		}
		
		// Canviem de l�nia
		printf("\n");
	}

}
